import json

#userPrefs.py
class UserPrefs(object):
    def __init__(self):
        try:
            with open("userprefs.txt", "rt") as fin:
                self.toPrefs = fin.read()
            self.userprefs = json.loads(self.toPrefs)
        except: pass
        
        try: self.username = self.userprefs["username"]
        except: self.username = "You"
        
        try: self.colorScheme = self.userprefs["colorscheme"]
        except: self.colorScheme = "dark"
        
        try: monday = ((self.userprefs["monday"]))
        except: monday = ()

        try: tuesday = self.userprefs["tuesday"]
        except: tuesday = ()

        try: wednesday = self.userprefs["wednesday"]
        except: wednesday = ()

        try: thursday = self.userprefs["thursday"]
        except: thursday = ()

        try: friday = self.userprefs["friday"]
        except: friday = ()

        try: saturday = self.userprefs["saturday"]
        except: saturday = ()

        try: sunday = self.userprefs["sunday"]
        except: sunday = ()

        self.preferredWorkTime = {
        0:monday,
        1:tuesday,
        2:wednesday,
        3:thursday,
        4:friday,
        5:saturday,
        6:sunday
        }
            
        self.colorConfig()

    def colorConfig(self):
        self.defFont = "Segoe UI Light"
        self.defBg = "#222222"
        self.defFg = "#EEEEEE"
        self.calendarBg = "#111111"
        self.calendarRectangle = "#BBBBBB"
        self.calendarFg = "#EEEEEE"
        self.superBarBg = "#333333"
        self.superBarFg = "#AAAAAA"
        self.superBarActiveFg = "#FFFFFF"
        self.eventColor = "#009900"
        self.reminderColor = "#cc9900"
        self.alarmColor = "#FF3333"
        self.workHourColor = "#222200"
        self.scheduleColor = "#0099cc"
        