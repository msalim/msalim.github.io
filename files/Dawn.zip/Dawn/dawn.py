#plan.py

#Plan v0.1.0a Release
#Changes from 0.0.3a: a lot
#Moved color schemes to userPrefs.py

#Modules:
#currentTime: calculates current local time for both display
#             and calculation on multiple modules
#events: analyses user input based on the typed
#        string in the superBar
#eventController: registers/delete the inputs
#nextEvent: finds the next event in the calendar
#nextAlarm: finds the next alarm in the calendar
#calConfig: provides configuration for the calendar UI

#THIS PROJECT CONSULTS A LOT FROM EFFBOT.ORG AND STACKOVERFLOW
#ALL CODES ADAPTED ARE GIVEN CREDIT IN THE TIMESHEET

from Tkinter import *
import calendar
import time
import datetime
import random
import webbrowser

import currentTime
import userPrefs
import events
import nextEvent
import nextAlarm
import calConfig
import eventController
import json
import re

print "hello"

class Plan(object):

    #initializes modules and important window information    
    def __init__(self):
        self.superTime = currentTime.CurrentTime()
        self.prefs = userPrefs.UserPrefs()
        self.events = events.Events()
        self.nextEvent = nextEvent.NextEvent()
        self.nextAlarm = nextAlarm.NextAlarm()
        self.calConfig = calConfig.CalConfig()
        self.eventController = eventController.EventController()
        self.eventsDict = self.eventController.eventsDict
        self.scheduleDict = self.eventController.scheduleDict
        self.window = Tk()
        self.winWidth = 1728
        self.winHeight = 960
        self.window.title("Plan (0.1.0 Alpha)")
        self.window.iconbitmap("transparent.ico")
        self.window.minsize(self.winWidth,self.winHeight)
        self.window.maxsize(self.winWidth,self.winHeight)
        self.calList = ([[self.prefs.calendarBg for x in xrange(7)]
                        for x in xrange(0, 86400, self.calConfig.interval)])
        self.window.configure(background=self.prefs.defBg)
        self.timerDelay = 999
        self.touchX = None
        self.touchY = None
        self.weekOffset = 0
        self.pastValue = 0
        self.pastAlarmValue = 0
        self.scrollCount = 0

    #calls everything UI
    def frameworkUI(self):
        self.frameFramework()
        self.canvasFramework()
        self.headerFrameUI()
        self.mainCalendarHeaderUI()
        self.addCalendarEventsUI()
        self.mainCalendarBoard()
        self.mainCalendarUI()
        self.bottomCanvasUI()

    #gives basic layout for the frame
    def frameFramework(self):
        self.calMargin = 10
        self.calHeight = ((self.winHeight-50-120-100-self.calMargin*2)
                            *2+self.calMargin*2)
        self.calLeftMargin = 120
        self.calRightMargin = 40
        self.totalHours = 24
        self.distance = self.calHeight/self.totalHours
        self.headerFrame = Frame(self.window,
            width=self.winWidth,
            height=50,
            background=self.prefs.defBg,
            highlightthickness=0)
        self.headerFrame.grid(row=0, column=0)
        self.footerFrame = Frame(self.window,
            width=self.winWidth,
            height=120,
            background=self.prefs.defBg,
            highlightthickness=0)
        self.footerFrame.grid(row=2, column=0)
        self.mainFrame = Frame(self.window,
            width=self.winWidth,
            height=self.winHeight-170,
            background=self.prefs.calendarBg,
            highlightthickness=0)
        self.mainFrame.grid(row=1, column=0)

    #provides canvases over the frame
    def canvasFramework(self):
        self.calendarHeader = Canvas(self.mainFrame,
            width=self.winWidth,
            height=100,
            background=self.prefs.calendarBg,
            relief="flat",
            borderwidth=0,
            scrollregion=(0,0,self.winWidth,self.calHeight+self.calMargin*2),
            highlightthickness=0)
        self.calendarHeader.grid(row=0,column=0,
            columnspan=self.window.winfo_width()/10-10) 

        self.mainCanvas = Canvas(self.mainFrame,
            width=self.winWidth,
            height=self.winHeight-270,
            background=self.prefs.calendarBg,
            relief="flat",
            borderwidth=0,
            scrollregion=(0,0,self.winWidth,self.calHeight+self.calMargin*2),
            highlightthickness=0)

        self.bottomCanvas = Canvas(self.footerFrame,
            width=self.winWidth,
            height=120,
            background=self.prefs.defBg,
            scrollregion=(0,0,100,1000),
            highlightthickness=0)
        self.bottomCanvas.grid(row=3, column=0,
            columnspan=self.window.winfo_width()/10)

    #adds superbar, help/preferences buttons, week-scroll, and name
    def headerFrameUI(self):
        self.superBar = Entry(self.headerFrame,
            width=self.winWidth/40,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 20, "italic"),
            relief="flat",
            foreground=self.prefs.superBarFg)

        self.superBar.insert(0, "Type 'help' for Superbar commands")
        self.superBar.grid(row=0, column=0, columnspan=15)

        self.helpButton = Button(self.headerFrame,
            command = lambda: self.showHelp(),
            background = self.prefs.defBg,
            relief = 'flat',
            text="      Help   ",
            foreground = self.prefs.defFg,
            font=(self.prefs.defFont, 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg)
        self.helpButton.grid(row=0, column=18)

        self.preferencesButton = Button(self.headerFrame,
            background = self.prefs.defBg,
            command = lambda: self.editPreferences(),
            relief = 'flat',
            text="   Preferences      ",
            foreground = self.prefs.defFg,
            font=(self.prefs.defFont, 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        self.preferencesButton.grid(row=0, column=19)

        self.previousWeek = Button(self.headerFrame,
            command = lambda: self.prevWeek(),
            background = self.prefs.defBg,
            relief = 'flat',
            text="<",
            foreground = self.prefs.defFg,
            font=("Segoe UI Light", 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        self.previousWeek.grid(row=0, column=20)

        self.afterWeek = Button(self.headerFrame,
            command = lambda: self.nextWeek(),
            background = self.prefs.defBg,
            relief = 'flat',
            text=">",
            foreground = self.prefs.defFg,
            font=("Segoe UI Light", 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        self.afterWeek.grid(row=0, column=21)

        self.userLabel = Label(self.headerFrame,
            text="    Welcome Back, %s!" % self.prefs.username,
            font= (self.prefs.defFont, 20),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg)
        self.userLabel.grid(row=0, column=22)

    #adds calendar's colours if available
    def mainCalendarBoard(self):
        for row in xrange(86400/self.calConfig.interval):
            for col in xrange(7):
                margin = 2
                x1 = self.calLeftMargin+self.xOffset*col+margin
                y1 = self.calMargin+self.distance*row/12
                x2 = x1+self.xOffset-margin
                y2 = y1+5
                self.mainCanvas.create_rectangle(x1,y1,x2,y2,
                    fill=self.calList[row][col],
                    outline=self.calList[row][col])

    #adds the "Week of" and Monday-Sunday + day number header
    def mainCalendarHeaderUI(self):    
        self.xOffset = ((self.winWidth-self.calLeftMargin-
            self.calRightMargin)/7)
        xOffset = self.xOffset
        x1 = self.calLeftMargin+xOffset/2
        x2 = self.calLeftMargin+xOffset*3/2
        x3 = self.calLeftMargin+xOffset*5/2
        x4 = self.calLeftMargin+xOffset*7/2
        x5 = self.calLeftMargin+xOffset*9/2
        x6 = self.calLeftMargin+xOffset*11/2
        x7 = self.calLeftMargin+xOffset*13/2
        x8 = self.calLeftMargin+xOffset*15/2
        cutoff = self.superTime.monthCutOff
        dayNumber = int(self.calConfig.startDay.tm_mday)
        self.calendarHeader.create_text(self.winWidth-self.calRightMargin,50,
            anchor="se",
            text="Week of %s %d, %d" % (self.calConfig.showMonth, dayNumber, self.calConfig.year),
            font=(self.prefs.defFont,22),
            fill=self.prefs.defFg)

        self.calendarHeader.create_text(x1,90,anchor="s",
            text="Monday %d" % (dayNumber%cutoff),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x2,90,anchor="s",
            text="Tuesday %d" % (((dayNumber+1-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x3,90,anchor="s",
            text="Wednesday %d" % (((dayNumber+2-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x4,90,anchor="s",
            text="Thursday %d" % (((dayNumber+3-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x5,90,anchor="s",
            text="Friday %d" % (((dayNumber+4-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x6,90,anchor="s",
            text="Saturday %d" % (((dayNumber+5-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)
        self.calendarHeader.create_text(x7,90,anchor="s",
            text="Sunday %d" % (((dayNumber+6-1)%cutoff)+1),
            font=(self.prefs.defFont,15),fill=self.prefs.defFg)

    #adds the time info on the left and the grid of the main calendar
    def mainCalendarUI(self):
        for y in xrange(self.totalHours):
            xOffset = ((self.winWidth-self.calLeftMargin-
                self.calRightMargin)/7)
            x1 = self.calLeftMargin
            x2 = self.calLeftMargin+xOffset
            x3 = self.calLeftMargin+xOffset*2
            x4 = self.calLeftMargin+xOffset*3
            x5 = self.calLeftMargin+xOffset*4
            x6 = self.calLeftMargin+xOffset*5
            x7 = self.calLeftMargin+xOffset*6
            x8 = self.calLeftMargin+xOffset*7
            
            y1 = (self.distance)*y+self.calMargin
            y2 = (self.distance)*y+self.calMargin+self.distance
            outline = self.prefs.calendarRectangle

            self.mainCanvas.create_rectangle(x1,y1,x2,y2,outline=outline)
            self.mainCanvas.create_rectangle(x2,y1,x3,y2,outline=outline)
            self.mainCanvas.create_rectangle(x3,y1,x4,y2,outline=outline)
            self.mainCanvas.create_rectangle(x4,y1,x5,y2,outline=outline)
            self.mainCanvas.create_rectangle(x5,y1,x6,y2,outline=outline)
            self.mainCanvas.create_rectangle(x6,y1,x7,y2,outline=outline)
            self.mainCanvas.create_rectangle(x7,y1,x8,y2,outline=outline)

        for y in xrange(self.totalHours/2):
            y1 = y*self.distance + self.calMargin
            y2 = y*self.distance + self.distance*12 + self.calMargin
            if y == 0: y = 12
            self.mainCanvas.create_text(110, y1,anchor="ne", text="%d:00AM" % y,
                font=(self.prefs.defFont, 12), fill=self.prefs.defFg)
            self.mainCanvas.create_text(110, y2,anchor="ne", text="%d:00PM" % y,
                font=(self.prefs.defFont, 12), fill=self.prefs.defFg)

        self.mainCanvas.grid(row=1,column=0,
            columnspan=self.window.winfo_width()/10-10)

    #adds the time/date display on the bottom
    def bottomCanvasUI(self):
        self.superTime = currentTime.CurrentTime()
        self.nextEvent = nextEvent.NextEvent()
        self.bottomCanvas.create_text(200,0,
            text=("%2d:%02d" % ((self.superTime.showHour-1)%12+1,
                self.superTime.minute)),
            anchor = "ne",
            font=(self.prefs.defFont, 50),
            fill=self.prefs.defFg)
        self.bottomCanvas.create_text(200,20,
            text=(":%02d" % self.superTime.second),
            anchor = "nw",
            font=(self.prefs.defFont, 20),
            fill=self.prefs.defFg)
        self.bottomCanvas.create_text(205,60,
            text=("%s" % self.superTime.AMPM),
            anchor = "nw",
            font=(self.prefs.defFont, 13),
            fill=self.prefs.defFg)

        self.bottomCanvas.create_text(380,20,
            text=("%s" % (self.superTime.showDayname)),
            anchor = "nw",
            font=(self.prefs.defFont, 20),
            fill=self.prefs.defFg)
        
        self.bottomCanvas.create_text(380,60,
            text=("%s" % (self.superTime.showMonth)),
            anchor = "nw",
            font=(self.prefs.defFont, 15),
            fill=self.prefs.defFg)

        self.bottomCanvas.create_text(370,0,
            text=("%s" % (self.superTime.day)),
            anchor = "ne",
            font=(self.prefs.defFont, 50),
            fill=self.prefs.defFg)

        try:
            self.bottomCanvas.create_text(600,20,
                text=("Your next %s is at %d:%02d%s on %s, %d %s %4d." %
                    (self.nextEvent.eventType, self.nextEvent.eventShowHour,
                        self.nextEvent.eventMin, self.nextEvent.AMPM,
                        self.nextEvent.eventDayName, self.nextEvent.eventDay,
                        self.nextEvent.eventMonthName, self.nextEvent.eventYear)),
                anchor = "nw",
                font=(self.prefs.defFont, 15),
                fill=self.prefs.defFg)
            self.bottomCanvas.create_text(600,45,
                text=(self.nextEvent.eventName.capitalize()),
                anchor = "nw",
                font=(self.prefs.defFont, 24),
                fill=self.prefs.defFg)

        except: pass

        try:
            if (self.nextAlarm.alarmTime - time.time()) < 86400:
                self.bottomCanvas.create_text(self.winWidth-100,20,
                    text=("Next alarm:"),
                    anchor = "ne",
                    font=(self.prefs.defFont, 15),
                    fill=self.prefs.defFg)
                self.bottomCanvas.create_text(self.winWidth-100,45,
                    text=("%d:%02d%s") % (self.nextAlarm.alarmShowHour,
                        self.nextAlarm.alarmMin, self.nextAlarm.AMPM),
                    anchor = "ne",
                    font=(self.prefs.defFont, 24),
                    fill=self.prefs.defFg)
        except: pass

    #adds the event colourings
    def addCalendarEventsUI(self):
        self.eventsDict = self.eventController.eventsDict
        self.scheduleDict = self.eventController.scheduleDict
        self.calList = ([[self.prefs.calendarBg for x in xrange(7)]
                for x in xrange(0, 86400, self.calConfig.interval)])
        #workdays first        
        for workDays in self.prefs.preferredWorkTime:
            totalWorkHours = tuple(int(v) for v in re.findall("[0-9]+",
                str(self.prefs.preferredWorkTime[workDays]))) #taken from stackoverflow
            for workHours in totalWorkHours:
                workMinutes = workHours*self.calConfig.interval/25
                for x in xrange(12):
                    try:
                        (self.calList[workMinutes+x]
                        [workDays]) = self.prefs.workHourColor
                    except: pass

        for key in self.eventsDict:
            if (int(key) >= self.calConfig.startDate and
                int(key) < self.calConfig.endDate):
                eventTime = time.localtime(int(key))
                eventSchedule = eventTime.tm_hour*12 + eventTime.tm_min/5
                if self.eventsDict[key][0] == "event":
                    (self.calList[eventSchedule]
                    [eventTime.tm_wday]) = self.prefs.eventColor
                    startTime = int(key)
                    endTime = int(self.eventsDict[key][2])
                    day = eventTime.tm_wday
                    if endTime != startTime:
                        if endTime < startTime:
                            endTime += 86400
                        while startTime < endTime:
                            eventSchedule += 1
                            while eventSchedule > 287:
                                eventSchedule -= 288
                                day += 1
                            if day > 6:
                                break
                            (self.calList[eventSchedule][day]) = self.prefs.eventColor
                            startTime += 300

                elif self.eventsDict[key][0] == "reminder":
                    (self.calList[eventSchedule]
                    [eventTime.tm_wday]) = self.prefs.reminderColor
                    startTime = int(key)
                    endTime = int(self.eventsDict[key][2])
                    day = eventTime.tm_wday
                    if endTime != startTime:
                        if endTime < startTime:
                            endTime += 86400
                        while startTime < endTime:
                            eventSchedule += 1
                            while eventSchedule > 287:
                                eventSchedule -= 288
                                day += 1
                            if day > 6:
                                break
                            (self.calList[eventSchedule][day]) = self.prefs.reminderColor
                            startTime += 300

                elif self.eventsDict[key][0] == "alarm":
                    (self.calList[eventSchedule]
                    [eventTime.tm_wday]) = self.prefs.alarmColor

        for key in self.scheduleDict:
            if self.scheduleDict[key][0] == "schedule":
                minimumTime = int(key)
                duration = int(self.scheduleDict[key][2])*60/self.calConfig.interval
                maximumTime = self.calConfig.absEndDate

                while duration > 0:
                    for col in xrange(7):
                        for row in xrange(86400/self.calConfig.interval):
                            startDay = self.calConfig.startDate
                            change = col*86400 + row*300 + self.weekOffset*7*86400
                            if change >= 7*86400 or duration == 0: break
                            if (self.calList[row][col] == self.prefs.workHourColor and
                                startDay + change >= minimumTime and
                                startDay + change < maximumTime):
                                self.calList[row][col] = self.prefs.scheduleColor
                                duration -= 1
                        if change >= 7*86400 or duration == 0: break
                    break


    #displays the reminders upon events and alarms
    def soundReminder(self):
        if int(time.time()) == self.pastValue:
            try:
                top = Toplevel()
                top.overrideredirect(1)
                canvas = Canvas(top,width = 900, height = 300,
                    bg=self.prefs.defBg, highlightthickness=0)
                canvas.pack()
                canvas.bind("<Button-1>", lambda e: top.destroy())
                canvas.bind("<Key>", lambda e: top.destroy())

                canvas.create_text(300,100,
                    text = ("%s at %d:%02d%s:" %
                        (self.nextEvent.eventType.capitalize(),
                        self.nextEvent.eventShowHour,
                        self.nextEvent.eventMin, self.nextEvent.AMPM)),
                    font = (self.prefs.defFont, 30),
                    fill = self.prefs.defFg)
                canvas.create_text(300,170,
                    text = (self.nextEvent.eventName.capitalize()),
                    font = (self.prefs.defFont, 50),
                    fill = self.prefs.defFg)
                canvas.create_text(300,270,
                    text = ("Click to close."),
                    font = (self.prefs.defFont, 20),
                    fill = self.prefs.defFg)
                top.geometry("%dx%d%+d%+d" % (600,300,
                    top.winfo_screenwidth()/2-600/2,
                    top.winfo_screenheight()/2-300/2))
            except: pass

        if int(time.time()) == self.pastAlarmValue:
            try:
                top = Toplevel()
                top.overrideredirect(1)
                canvas = Canvas(top,width = 900, height = 300,
                    bg=self.prefs.defBg, highlightthickness=0)
                canvas.pack()
                canvas.bind("<Button-1>", lambda e: top.destroy())
                canvas.bind("<Key>", lambda e: top.destroy())

                canvas.create_text(300,100,
                    text=("Alarm"),
                    font = (self.prefs.defFont, 30),
                    fill = self.prefs.defFg)
                canvas.create_text(300,170,
                    text=("%d:%02d%s") % (self.nextAlarm.alarmShowHour,
                        self.nextAlarm.alarmMin, self.nextAlarm.AMPM),
                    font = (self.prefs.defFont, 50),
                    fill = self.prefs.defFg)
                canvas.create_text(300,270,
                    text = ("Click to close."),
                    font = (self.prefs.defFont, 20),
                    fill = self.prefs.defFg)
                top.geometry("%dx%d%+d%+d" % (600,300,
                    top.winfo_screenwidth()/2-600/2,
                    top.winfo_screenheight()/2-300/2))
            except: pass

        self.pastValue = self.nextEvent.minValue
        self.pastAlarmValue = self.nextAlarm.minValue

    #requests text from Superbar
    def getSuperBarText(self):
        if self.superBar.get() == ("Type 'help' for Superbar commands"):
            self.superBar.delete(0, END)
            self.superBar.configure(
                foreground=self.prefs.superBarActiveFg,
                font = ("Segoe UI Light", 20))
        if self.superBar.get() != "":
            self.searchForText()

    #updates the query if possible
    def queryUpdate(self):
        try:
            self.queryCanvas.delete(ALL)
            if self.superBar.get() == "help":
                self.queryCanvas.create_text(10,10,
                    anchor = "nw",
                    text=("Press enter for help"),
                    font = (self.prefs.defFont, 15),
                    fill = self.prefs.defFg)
            elif self.superBar.get() != "":
                self.queryCanvas.create_text(10,10,
                    anchor = "nw",
                    text=("Press enter to %s '%s'" %
                        (self.eventController.checkEvent(self.superBar.get()),
                        self.superBar.get())),
                    font = (self.prefs.defFont, 15),
                    fill = self.prefs.defFg)
            else:
                self.queryCanvas.create_text(10,10,
                    anchor = "nw",
                    text=("Type 'help' for Superbar commands"),
                    font = (self.prefs.defFont, 15, "italic"),
                    fill = self.prefs.defFg)
            
        except: self.queryCreate()
    
    #creates the query canvas
    def queryCreate(self):
        self.queryBar = Toplevel()
        self.queryBar.overrideredirect(1)
        self.queryCanvas = Canvas(self.queryBar,width = 735, height = 60,
            bg=self.prefs.superBarBg, highlightthickness=0)
        self.queryCanvas.pack()
        self.queryCanvas.bind("<Button-1>", (lambda e:
            self.returnBind()))
        if self.superBar.get() != "":
            self.queryCanvas.create_text(10,10,
                anchor = "nw",
                text=("Press enter to %s '%s'" %
                    (self.eventController.checkEvent(self.superBar.get()),
                    self.superBar.get())),
                font = (self.prefs.defFont, 15),
                fill = self.prefs.defFg)
        else:
            self.queryCanvas.create_text(10,10,
                anchor = "nw",
                text=("Type 'help' for Superbar commands"),
                font = (self.prefs.defFont, 15),
                fill = self.prefs.defFg)
        self.queryBar.geometry("%dx%d%+d%+d" % (735,60,
            self.queryBar.winfo_screenwidth()/2-600/2-460,
            self.queryBar.winfo_screenheight()/2-300/2-237))
        self.calendarHeader.delete(ALL)
        self.mainCalendarHeaderUI()

        #wrapper for query canvas
    def searchForText(self):
        if (self.superBar.get() != ("Type 'help' for Superbar commands")
            and self.superBar.get() != ""):
            try:
                self.queryCanvas.after(10, lambda: self.queryUpdate())
            except:
                self.calendarHeader.after(10, lambda: self.queryCreate())
        
        #performs actions parsed from the Superbar text
    def registerSuperBarText(self):
        event = self.superBar.get()
        if event.lower() == "help": return self.showHelp()
        if event == "": return
        text = self.eventController.addEvents(event)
        self.nextEvent = nextEvent.NextEvent()
        self.nextAlarm = nextAlarm.NextAlarm()
        self.redrawCalendar()
        self.calendarHeader.create_text(self.calLeftMargin,50,
            anchor="sw",
            text="%s: %s" % (text, event),
            font=(self.prefs.defFont,22),
            fill=self.prefs.defFg)

    #adds support for touch scrolling (experimental)
    def touchScroll(self,event):
        if self.touchY != None:
            deltaY = float(event.y-self.touchY)
            try: self.scrollY += deltaY/20
            except: self.scrollY = 0
            self.mainCanvas.yview_scroll(-1*int(round(self.scrollY)), "units")
            if abs(self.scrollY) >= 1: self.scrollY = 0
        self.touchY = event.y

    #enables the hovered information below the superbar
    def hoverOver(self,event):
        try:
            self.queryBar.destroy()
        except: pass
        x = event.x
        col = (event.x - self.calLeftMargin)/self.xOffset
        row = int(float(event.y - self.calMargin + self.scrollCount * 69)/
            self.distance * (3600/self.calConfig.interval))
        try:
            self.calList[row][col] != self.prefs.calendarBg
        except: return
        if (self.calList[row][col] != self.prefs.calendarBg and 
            self.calList[row][col] != self.prefs.workHourColor and
            self.calList[row][col] != self.prefs.scheduleColor):
            for x in xrange(6):
                key = str((self.calConfig.startDate + col*86400 + row*300)
                        +time.timezone+x*60)
                d = self.eventsDict
                eventTime = time.localtime(int(key))
                if eventTime.tm_hour >= 12: AMPM = "PM"
                else: AMPM = "AM" 
                hour = ((eventTime.tm_hour-1)%12)+1
                minute = eventTime.tm_min
                day = eventTime.tm_mday
                monthList = ["January", "February", "March", "April",
                "May", "June", "July", "August", "September", "October",
                "November", "December"]
                month = monthList[eventTime.tm_mon-1]
                try:
                    testKey = d[key][1] #crashes if didn't work
                    self.calendarHeader.delete(ALL) #canvas preserved on crash
                    self.calendarHeader.create_text(self.calLeftMargin,50,
                    anchor="sw",
                    text=("%s: %s | %d:%02d%s, %d %s" %
                        (d[key][0].capitalize(), d[key][1].capitalize(),
                        hour, minute, AMPM, day, month)),
                    font=(self.prefs.defFont,22),fill=self.prefs.defFg)
                    self.mainCalendarHeaderUI()
                    return
                except: pass
            interval = 0
            while True and interval > -500:
                try:
                    key = str((self.calConfig.startDate + col*86400 + row*300)
                        +time.timezone+interval*60)
                    eventTime = time.localtime(int(key))
                    if eventTime.tm_hour >= 12: AMPM = "PM"
                    else: AMPM = "AM" 
                    hour = ((eventTime.tm_hour-1)%12)+1
                    minute = eventTime.tm_min
                    self.calendarHeader.delete(ALL)
                    self.calendarHeader.create_text(self.calLeftMargin,50,
                    anchor="sw",
                    text=("%s: %s | %d:%02d%s, %d %s" %
                        (d[key][0].capitalize(), d[key][1].capitalize(),
                        hour, minute, AMPM, day, month)),
                    font=(self.prefs.defFont,22),fill=self.prefs.defFg)
                    self.mainCalendarHeaderUI()
                    return
                except:
                    interval -= 1

        elif (self.calList[row][col] != self.prefs.calendarBg and 
            self.calList[row][col] != self.prefs.workHourColor and
            self.calList[row][col] == self.prefs.scheduleColor):
                for x in xrange(6):
                    key = str((self.calConfig.startDate + col*86400 + row*300)
                            +time.timezone+x*60)
                    d = self.scheduleDict
                    eventTime = time.localtime(int(key))
                    if eventTime.tm_hour >= 12: AMPM = "PM"
                    else: AMPM = "AM" 
                    hour = ((eventTime.tm_hour-1)%12)+1
                    minute = eventTime.tm_min
                    day = eventTime.tm_mday
                    monthList = ["January", "February", "March", "April",
                    "May", "June", "July", "August", "September", "October",
                    "November", "December"]
                    month = monthList[eventTime.tm_mon-1]
                    try:
                        testKey = d[key][1]
                        self.calendarHeader.delete(ALL)
                        self.calendarHeader.create_text(self.calLeftMargin,50,
                        anchor="sw",
                        text=("%s: %s | %d %s" %
                            (d[key][0].capitalize(), d[key][1].capitalize(),
                            day, month)),
                        font=(self.prefs.defFont,22),fill=self.prefs.defFg)
                        self.mainCalendarHeaderUI()
                        return
                    except: pass
                interval = 0
                while True and interval > -10080:
                    try:
                        key = str((self.calConfig.startDate + col*86400 + row*300)
                            +time.timezone+interval*60)
                        eventTime = time.localtime(int(key))
                        if eventTime.tm_hour >= 12: AMPM = "PM"
                        else: AMPM = "AM"
                        hour = ((eventTime.tm_hour-1)%12)+1
                        minute = eventTime.tm_min
                        self.calendarHeader.delete(ALL)
                        self.calendarHeader.create_text(self.calLeftMargin,50,
                        anchor="sw",
                        text=("%s: %s | %d %s" %
                            (d[key][0].capitalize(), d[key][1].capitalize(),
                            day, month)),
                        font=(self.prefs.defFont,22),fill=self.prefs.defFg)
                        self.mainCalendarHeaderUI()
                        return
                    except:
                        interval -= 1

    #enables hovering after the calendar is scrolled
    def mouseScroll(self,event):
        self.mainCanvas.yview_scroll(-1*(event.delta/120), "units")
        if event.delta < 0:
            self.scrollCount += 1
            if self.scrollCount > 10: self.scrollCount = 10
        elif event.delta > 0:
            self.scrollCount -= 1
            if self.scrollCount < 0: self.scrollCount = 0

    #change weeks
    def prevWeek(self, *args):
        self.weekOffset -= 1
        self.calConfig.modifyCalendar(self.weekOffset)
        self.redrawCalendar()

    def nextWeek(self, *args):
        self.weekOffset += 1
        self.calConfig.modifyCalendar(self.weekOffset)
        self.redrawCalendar()

    #redraws the whole calendar
    def redrawCalendar(self):
        self.calendarHeader.delete(ALL)
        self.mainCanvas.delete(ALL)
        self.addCalendarEventsUI()
        self.mainCalendarHeaderUI()
        self.mainCalendarBoard()
        self.mainCalendarUI()

    def onTimerFiredWrapper(self):
        if (self.timerDelay == None):
            return # turns off timer
        self.redrawBottomCanvas()
        self.bottomCanvas.after(self.timerDelay, self.onTimerFiredWrapper)

    def redrawBottomCanvas(self):
        self.bottomCanvas.delete(ALL)
        self.soundReminder()
        self.bottomCanvasUI()
        #self.headerFrame.configure(width=self.winWidth)
        #self.footerFrame.configure(width=self.window.winfo_width())
        #self.mainFrame.configure(width=self.window.winfo_width(),height=self.winHeight-170)
        #self.superBar.configure(width=min(30,self.window.winfo_width()/40))
        #self.headerCanvas.configure(width=self.window.winfo_width())
        #self.mainCanvas.configure(height=self.window.winfo_height()-270)
        #self.mainCanvas.grid(row=2, column=0,
        #    columnspan=self.window.winfo_width()/10)
        #self.bottomCanvas.configure(width=self.window.winfo_width())
        #self.bottomCanvas.grid(row=3, column=0,
        #    columnspan=self.window.winfo_width()/10)
        #self.touchY = None

    #calls edit event when appropriate
    def clickEvent(self, event):
        try:
            self.queryBar.destroy()
        except: pass
        interval = 0
        x = event.x
        col = (event.x - self.calLeftMargin)/self.xOffset
        row = int(float(event.y - self.calMargin + self.scrollCount * 69)/
            self.distance * (3600/self.calConfig.interval))
        if (self.calList[row][col] != self.prefs.calendarBg and 
            self.calList[row][col] != self.prefs.workHourColor):
            for x in xrange(6):
                key = str((self.calConfig.startDate + col*86400 + row*300)
                        +time.timezone+x*60)
                d = self.eventsDict
                if self.calList[row][col] == self.prefs.scheduleColor:
                    d = self.scheduleDict
                eventTime = time.localtime(int(key))
                if eventTime.tm_hour >= 12: AMPM = "PM"
                else: AMPM = "AM" 
                hour = ((eventTime.tm_hour-1)%12)+1
                minute = eventTime.tm_min
                day = eventTime.tm_mday
                monthList = ["January", "February", "March", "April",
                "May", "June", "July", "August", "September", "October",
                "November", "December"]
                month = monthList[eventTime.tm_mon-1]
                try:
                    if self.calList[row][col] == self.prefs.scheduleColor:
                        return self.createEditEventUI(d, key, eventType="schedule")
                    return self.createEditEventUI(d, key)
                except: pass

            while True and interval > -10080:
                    try:
                        key = str((self.calConfig.startDate + col*86400 + row*300)
                            +time.timezone+interval*60)
                        eventTime = time.localtime(int(key))
                        if eventTime.tm_hour >= 12: AMPM = "PM"
                        else: AMPM = "AM" 
                        hour = ((eventTime.tm_hour-1)%12)+1
                        minute = eventTime.tm_min
                        if self.calList[row][col] == self.prefs.scheduleColor:
                            return self.createEditEventUI(d, key, eventType="schedule")
                        return self.createEditEventUI(d, key)
                    except:
                        interval -= 1
        
    #adds edit event window
    def createEditEventUI(self, d, key, eventType=0):
        event = d[key]
        self.editEventWindow = Toplevel()
        self.editEventWindow.configure(width=400,height=400,
            background=self.prefs.defBg)
        self.editEventWindow.overrideredirect(1)
        headerlabel = Label(self.editEventWindow,
            text = " Edit Entry",
            font = (self.prefs.defFont, 30),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        headerlabel.grid(row=0, column=0, columnspan=3)
        typelabel = Label(self.editEventWindow,
            text = "Type:",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        typelabel.grid(row=1, column=0, columnspan=2)
        typeentry = Label(self.editEventWindow,
            text = d[key][0].capitalize(),
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        typeentry.grid(row=1, column=2, columnspan=3)
        desclabel = Label(self.editEventWindow,
            text = " Description: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        desclabel.grid(row=2, column=0, columnspan=2)
        descentry = Entry(self.editEventWindow,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        descentry.insert(0, d[key][1].capitalize())
        descentry.grid(row=2, column=2, columnspan=3)
        if eventType == "schedule":
            timelabel = Label(self.editEventWindow,
                text = "Duration:",
                font = (self.prefs.defFont, 15),
                foreground = self.prefs.defFg,
                background = self.prefs.defBg,
                anchor = "w")
            timelabel.grid(row=3, column=0, columnspan=2)
            timeentry = Entry(self.editEventWindow,
                width=18,
                background=self.prefs.superBarBg,
                font=("Segoe UI Light", 15),
                relief="flat",
                foreground=self.prefs.defFg)
        else:
            timelabel = Label(self.editEventWindow,
                text = "Time:",
                font = (self.prefs.defFont, 15),
                foreground = self.prefs.defFg,
                background = self.prefs.defBg,
                anchor = "w")
            timelabel.grid(row=3, column=0, columnspan=2)
            timeentry = Entry(self.editEventWindow,
                width=18,
                background=self.prefs.superBarBg,
                font=("Segoe UI Light", 15),
                relief="flat",
                foreground=self.prefs.defFg)
        eventTime = time.localtime(int(key))
        hour = int(eventTime.tm_hour)
        showHour = (hour-1)%12+1
        if hour%24 < 12:
            AMPM = "AM"
        else: AMPM = "PM"
        if eventType == "schedule":
            if (int(d[key][2])/60) == 1: timeNotation = "hour"
            else: timeNotation = "hours"
            timeentry.insert(0, "%d %s" % ((int(d[key][2])/60), timeNotation))
            timeentry.grid(row=3, column=2, columnspan=3)
        else:
            if (int(d[key][2]) != int(key)-86400) and (int(d[key][2]) != int(key)):
                eventEndTime = time.localtime(int(d[key][2]))
                endHour = int(eventEndTime.tm_hour)
                showEndHour = (endHour-1)%12+1
                if endHour%24 < 12:
                    endAMPM = "AM"
                else: endAMPM = "PM"
                timeentry.insert(0, "%d:%02d%s to %d:%02d%s" % (showHour,
                    int(eventTime.tm_min), AMPM, showEndHour,
                    int(eventEndTime.tm_min), endAMPM))
                timeentry.grid(row=3, column=2, columnspan=3)
            else:
                timeentry.insert(0, "%d:%02d%s" % (showHour,
                    int(eventTime.tm_min), AMPM))
                timeentry.grid(row=3, column=2, columnspan=3)

        datelabel = Label(self.editEventWindow,
            text = "Date:",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        datelabel.grid(row=4, column=0, columnspan=2)
        
        dateentry = Entry(self.editEventWindow,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        eventTime = time.localtime(int(key))
        day = int(eventTime.tm_mday)
        month = int(eventTime.tm_mon)
        monthName = ["January", "February", "March", "April",
            "May", "June", "July", "August", "September",
            "October", "November", "December"]
        showMonth = monthName[month-1]
        year = int(eventTime.tm_year)
        showHour = (hour-1)%24+1
        if hour%24 < 12:
            AMPM = "AM"
        else: AMPM = "PM" 
        dateentry.insert(0, "%d %s %d" % (day, showMonth, year))
        dateentry.grid(row=4, column=2, columnspan=3)


        confirmChange = Button(self.editEventWindow,
            command = lambda: self.addNewEvent(d, key,
                descentry.get(), timeentry.get(), dateentry.get(),
                eventType),
            background = self.prefs.defBg,
            relief = 'flat',
            text="Confirm",
            foreground = self.prefs.defFg,
            font=("Segoe UI Light", 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        confirmChange.grid(row=5, column=0, columnspan=2)

        deleteChange = Button(self.editEventWindow,
            command = lambda: self.deleteEvent(d, key, eventType),
            background = self.prefs.defBg,
            relief = 'flat',
            text="Delete",
            foreground = self.prefs.defFg,
            font=("Segoe UI Light", 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        deleteChange.grid(row=5, column=2, columnspan=2)


        cancelChange = Button(self.editEventWindow,
            command = lambda: self.editEventWindow.destroy(),
            background = self.prefs.defBg,
            relief = 'flat',
            text="Cancel",
            foreground = self.prefs.defFg,
            font=(self.prefs.defFont, 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        cancelChange.grid(row=5, column=4, columnspan=2)


        
        self.editEventWindow.geometry("%dx%d%+d%+d" % (400,400,
            self.editEventWindow.winfo_screenwidth()/2+473,
            self.editEventWindow.winfo_screenheight()/2-(self.winHeight-170)/2+240))

    #adds new event based on editEventUI
    def addNewEvent(self, d, key, desc, time, date, eventType=0):
        eventType = d[key][0]
        self.eventController.addEvents("delete %s" % d[key][1].capitalize())
        if eventType != "event":
            self.eventController.addEvents("%s %s %s %s" % (eventType,
            desc, time, date), override=1)
        else: self.eventController.addEvents("%s %s %s" % (
            desc, time, date), override=1)
        self.editEventWindow.destroy()
        self.redrawCalendar()        
        self.calendarHeader.create_text(self.calLeftMargin,50,
                    anchor="sw",
                    text=("%s updated." % eventType.capitalize()),
                    font=(self.prefs.defFont,22),fill=self.prefs.defFg)    
        return

    #deletes event based on editEventUI
    def deleteEvent(self, d, key, eventType=0):
        eventType = d[key][0]
        if eventType == "schedule":
            self.eventController.addEvents("delete schedule",
            override=1)
        else:
            self.eventController.addEvents(("delete %s" %
                d[key][1].capitalize()), override=1)
        self.editEventWindow.destroy()
        self.redrawCalendar()
        self.calendarHeader.create_text(self.calLeftMargin,50,
            anchor="sw",
            text=("%s deleted." % eventType.capitalize()),
            font=(self.prefs.defFont,22),fill=self.prefs.defFg)

    #shows helpscreen
    def showHelp(self):
        self.help = Toplevel()
        self.help.overrideredirect(1)
        self.help.title("Help - Plan (0.1.0 Alpha)")
        self.help.bind("<Button-1>", lambda e: self.help.destroy())
        self.help.iconbitmap("transparent.ico")
        self.help.configure(bg=self.prefs.defBg)
        canvas = Canvas(self.help, width = 1300, height = 700, bg="#222222")
        canvas.pack()
        image = PhotoImage(file = 'helpscreen.gif')
        canvas.create_image(0, 0, image = image, anchor = NW)
        windowWidth = 1300
        windowHeight = 700
        self.help.geometry("%dx%d%+d%+d" %
            (windowWidth,windowHeight,
            self.help.winfo_screenwidth()/2-windowWidth/2,
            self.help.winfo_screenheight()/2-windowHeight/2))
        self.help.mainloop()

    #shows prefs screen
    def editPreferences(self):
        try:
            with open("userprefs.txt", "rt") as fin:
                self.toPrefs = fin.read()
            d = json.loads(self.toPrefs)
        except: d = {}
        self.preferences = Toplevel()
        self.preferences.overrideredirect(1)
        self.preferences.title("Preferences - Plan (0.1.0 Alpha)")
        self.preferences.iconbitmap("transparent.ico")
        self.preferences.configure(bg=self.prefs.defBg)
        headerlabel = Label(self.preferences,
            text = "Preferences",
            font = (self.prefs.defFont, 30),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        headerlabel.grid(row=0, column=0, columnspan=3)
        userlabel = Label(self.preferences,
            text = "User: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        userlabel.grid(row=2, column=0, columnspan=2)
        userentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            userentry.insert(0, d["username"].capitalize())
        except: pass
        userentry.grid(row=2, column=2, columnspan=3)

        colorlabel = Label(self.preferences,
            text = " Color Scheme: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        colorlabel.grid(row=3, column=0, columnspan=2)
        colorentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            colorentry.insert(0, d["colorscheme"].capitalize())
        except: pass
        colorentry.grid(row=3, column=2, columnspan=3)

        worklabel = Label(self.preferences,
            text = "  Preferred Work Hours",
            font = (self.prefs.defFont, 20),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        worklabel.grid(row=4, column=0, columnspan=3)

        mondaylabel = Label(self.preferences,
            text = "Monday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        mondaylabel.grid(row=5, column=0, columnspan=2)
        mondayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            mondayentry.insert(0, d["monday"].capitalize())
        except: pass
        mondayentry.grid(row=5, column=2, columnspan=3)

        tuesdaylabel = Label(self.preferences,
            text = "Tuesday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        tuesdaylabel.grid(row=6, column=0, columnspan=2)
        tuesdayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            tuesdayentry.insert(0, d["tuesday"].capitalize())
        except: pass
        tuesdayentry.grid(row=6, column=2, columnspan=3)

        wednesdaylabel = Label(self.preferences,
            text = "Wednesday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        wednesdaylabel.grid(row=7, column=0, columnspan=2)
        wednesdayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            wednesdayentry.insert(0, d["wednesday"].capitalize())
        except: pass
        wednesdayentry.grid(row=7, column=2, columnspan=3)

        thursdaylabel = Label(self.preferences,
            text = "Thursday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        thursdaylabel.grid(row=8, column=0, columnspan=2)
        thursdayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            thursdayentry.insert(0, d["thursday"].capitalize())
        except: pass
        thursdayentry.grid(row=8, column=2, columnspan=3)

        fridaylabel = Label(self.preferences,
            text = "Friday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        fridaylabel.grid(row=9, column=0, columnspan=2)
        fridayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            fridayentry.insert(0, d["friday"].capitalize())
        except: pass
        fridayentry.grid(row=9, column=2, columnspan=3)

        saturdaylabel = Label(self.preferences,
            text = "Saturday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        saturdaylabel.grid(row=10, column=0, columnspan=2)
        saturdayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            saturdayentry.insert(0, d["saturday"].capitalize())
        except: pass
        saturdayentry.grid(row=10, column=2, columnspan=3)

        sundaylabel = Label(self.preferences,
            text = "Sunday: ",
            font = (self.prefs.defFont, 15),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg,
            anchor = "w")
        sundaylabel.grid(row=11, column=0, columnspan=2)
        sundayentry = Entry(self.preferences,
            width=18,
            background=self.prefs.superBarBg,
            font=("Segoe UI Light", 15),
            relief="flat",
            foreground=self.prefs.defFg)
        try:
            sundayentry.insert(0, d["sunday"].capitalize())
        except: pass
        sundayentry.grid(row=11, column=2, columnspan=3)

        confirmButton = Button(self.preferences,
            command = lambda: self.savePreferences(d, userentry.get(),
                colorentry.get(), mondayentry.get(), tuesdayentry.get(),
                wednesdayentry.get(), thursdayentry.get(),
                fridayentry.get(), saturdayentry.get(), sundayentry.get()),
            background = self.prefs.defBg,
            relief = 'flat',
            text="Confirm",
            foreground = self.prefs.defFg,
            font=("Segoe UI Light", 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        confirmButton.grid(row=12, column=0, columnspan=3)

        cancelButton = Button(self.preferences,
            command = lambda: self.preferences.destroy(),
            background = self.prefs.defBg,
            relief = 'flat',
            text="Cancel",
            foreground = self.prefs.defFg,
            font=(self.prefs.defFont, 15),
            height=1,
            activebackground = self.prefs.defBg,
            activeforeground = self.prefs.defFg,
            takefocus=0)
        cancelButton.grid(row=12, column=3, columnspan=2)

        windowWidth = 450
        windowHeight = 560
        self.preferences.geometry("%dx%d%+d%+d" %
            (windowWidth,windowHeight,
            self.preferences.winfo_screenwidth()/2-windowWidth/2,
            self.preferences.winfo_screenheight()/2-windowHeight/2))

    #saves prefs
    def savePreferences(self, d, user, color,
        mon, tue, wed, thu, fri, sat, sun):
        d["username"] = user
        d["colorscheme"] = color
        d["monday"] = mon
        d["tuesday"] = tue
        d["wednesday"] = wed
        d["thursday"] = thu
        d["friday"] = fri
        d["saturday"] = sat
        d["sunday"] = sun
        prefs = json.dumps(d)
        with open("userprefs.txt", "wt") as fout:
            fout.write(prefs)
        self.prefs = userPrefs.UserPrefs()
        self.redrawCalendar()
        self.userLabel = Label(self.headerFrame,
            text="    Welcome Back, %s!" % self.prefs.username,
            font= (self.prefs.defFont, 20),
            foreground = self.prefs.defFg,
            background = self.prefs.defBg)
        self.userLabel.grid(row=0, column=22)
        self.calendarHeader.create_text(self.calLeftMargin,50,
            anchor="sw",
            text=("Preferences saved."),
            font=(self.prefs.defFont,22),fill=self.prefs.defFg)
        try: self.preferences.destroy()
        except: pass

    #wrapper to register Superbar text
    def returnBind(self):
        try:
            self.queryBar.destroy()
        except: pass
        self.registerSuperBarText()

    #runs the program
    def run(self):
        self.frameworkUI()
        self.addCalendarEventsUI()
        self.calendarHeader.create_text(self.calLeftMargin,50,
                    anchor="sw",
                    text=("Press tab to activate Superbar"),
                    font=(self.prefs.defFont,22),fill=self.prefs.defFg)
        self.superBar.bind("<Button-1>", lambda e: self.getSuperBarText())
        self.superBar.bind("<Key>", lambda e: self.getSuperBarText())
        self.superBar.bind("<Return>", lambda e: self.returnBind())
        self.mainCanvas.bind('<Button-1>', lambda event: self.clickEvent(event))
        self.mainCanvas.bind("<B1-Motion>", lambda event: self.touchScroll(event))
        self.window.bind_all("<MouseWheel>", lambda event: self.mouseScroll(event))
        self.mainCanvas.bind("<Motion>", lambda event: self.hoverOver(event))
        self.window.geometry("%dx%d%+d%+d" % (self.winWidth, self.winHeight,
            self.window.winfo_screenwidth()/2-self.winWidth/2,
            self.window.winfo_screenheight()/2-self.winHeight/2))
        self.onTimerFiredWrapper()
        self.mainCanvas.yview_scroll(120000, "units")
        self.scrollCount = 10
        self.window.mainloop()

a = Plan()
a.run()























#LA LA LA LA LA LA LA LA LA LA
























