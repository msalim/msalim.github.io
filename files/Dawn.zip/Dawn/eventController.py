import events
import calendar
import json
import currentTime
import webbrowser
import time

from Tkinter import *
import userPrefs

class EventController(object):

    def __init__(self, text=""):
        self.prefs = userPrefs.UserPrefs()
        self.currentTime = currentTime.CurrentTime()
        self.events = events.Events(text)
        try:
            with open("eventdata.txt", "rt") as fin:
                self.toDict = fin.read()
            self.eventsDict = json.loads(self.toDict)
        except: self.eventsDict = {}
        try:
            with open("scheduledata.txt", "rt") as fin:
                self.toSchedDict = fin.read()
            self.scheduleDict = json.loads(self.toSchedDict)
        except: self.scheduleDict = {}

    def checkEvent(self, text):
        self.event = events.Events(text)
        self.currentTime = currentTime.CurrentTime()
        event = self.event
        if "delete" in text: return "delete"
        if (event.eventHour == self.currentTime.gmthour and
            event.eventMinute == self.currentTime.gmtminute and
            event.eventDay == self.currentTime.gmtday):
            return "search for"
        return "register %s" % event.eventType

    def addEvents(self, text, override=0):
       # try:
            self.event = events.Events(text)
            if self.event.eventType == "delete":
                return self.removeFromDict(text, override)
            elif self.event.eventType == "schedule":
                return self.writeToScheduleDict()
            else:
                if override == 1:
                    return self.directWriteToDict(text)
                return self.writeToDict(text)
       # except: return "Error: event not added. Please try again"

    def removeFromDict(self, text, override=0):
        if "schedule" in text:
            self.scheduleDict = {}
            self.toSchedWrite = json.dumps(self.scheduleDict)
            with open("scheduledata.txt", "wt") as fout:
                fout.write(self.toSchedWrite)
            return "Schedule deleted"
        minKey = 999999999999999
        for key in self.eventsDict:
            if override == 1:
                if (self.eventsDict[key][1].lower() == text[7:].lower()):
                    if minKey > int(key):
                        minKey = int(key) 
            else:
                if (self.eventsDict[key][1].lower() == text[7:].lower() and
                    int(key) > time.time()):
                    if minKey > int(key):
                        minKey = int(key)
        if minKey == 999999999999999: return "Nothing to delete"
        else:
            del self.eventsDict[unicode(minKey)]
            self.toWrite = json.dumps(self.eventsDict)
            with open("eventdata.txt", "wt") as fout:
                fout.write(self.toWrite)
            return "Event deleted"

    def writeToDict(self, text):
        self.currentTime = currentTime.CurrentTime()
        event = self.event
        key = unicode(int(calendar.timegm((event.eventYear, event.eventMonth,
            event.eventDay, event.eventHour, event.eventMinute, 0))))
        end = unicode(int(calendar.timegm((event.eventYear, event.eventMonth,
            event.eventEndDay, event.eventEndHour, event.eventEndMinute, 0))))
        
        value = [unicode(event.eventType),
        unicode(event.eventDescription), end]
        
        try:
            if self.eventsDict[key][0] != None:

                self.top = Toplevel()
                self.top.configure(bg=self.prefs.defBg)
                self.top.overrideredirect(1)
                canvas = Canvas(self.top,width = 550, height = 60,
                    bg=self.prefs.superBarBg, highlightthickness=0)
                canvas.grid(row=0, column=0, columnspan=8)
                canvas.create_text(10,10,
                    anchor = "nw",
                    text = ("Overwrite %s '%s'?" % (self.eventsDict[key][0],
                        self.eventsDict[key][1])),
                    font = (self.prefs.defFont, 15),
                    fill = self.prefs.defFg)
                confirmChange = Button(self.top,
                    command = lambda: self.directWriteToDict(text),
                    background = self.prefs.defBg,
                    relief = 'flat',
                    text="Confirm",
                    foreground = self.prefs.defFg,
                    font=("Segoe UI Light", 15),
                    height=1,
                    activebackground = self.prefs.defBg,
                    activeforeground = self.prefs.defFg,
                    takefocus=0)
                confirmChange.grid(row=0, column=9, columnspan=2)

                cancelChange = Button(self.top,
                    command = lambda: self.top.destroy(),
                    background = self.prefs.defBg,
                    relief = 'flat',
                    text="Cancel",
                    foreground = self.prefs.defFg,
                    font=(self.prefs.defFont, 15),
                    height=1,
                    activebackground = self.prefs.defBg,
                    activeforeground = self.prefs.defFg,
                    takefocus=0)
                cancelChange.grid(row=0, column=11, columnspan=2)
                self.top.geometry("%dx%d%+d%+d" %
                    (778,60, #http://stackoverflow.com/questions/3352918/how-to-center-a-window-on-the-screen-in-tkinter
                    self.top.winfo_screenwidth()/2-600/2-483,
                    self.top.winfo_screenheight()/2-300/2-237))
                self.top.mainloop()
        except: pass
        
        if (int(event.eventHour) == int(self.currentTime.gmthour) and 
            int(event.eventMinute) == int(self.currentTime.gmtminute)):
            url = "https://www.google.com/#q=%s" % text
            webbrowser.open(url, new=0, autoraise=True)
            return "Searched"
        self.eventsDict[key] = value
        self.toWrite = json.dumps(self.eventsDict)
        with open("eventdata.txt", "wt") as fout:
            fout.write(self.toWrite)
            return "Event added"
      
    def directWriteToDict(self, text):
        self.currentTime = currentTime.CurrentTime()
        event = self.event
        key = unicode(int(calendar.timegm((event.eventYear, event.eventMonth,
            event.eventDay, event.eventHour, event.eventMinute, 0))))
        end = unicode(int(calendar.timegm((event.eventYear, event.eventMonth,
            event.eventEndDay, event.eventEndHour, event.eventEndMinute, 0))))
        
        value = [unicode(event.eventType),
        unicode(event.eventDescription), end]

        try:
            self.top.destroy()
        except: pass

        self.eventsDict[key] = value
        self.toWrite = json.dumps(self.eventsDict)
        with open("eventdata.txt", "wt") as fout:
            fout.write(self.toWrite)
        return "Event added"


    def writeToScheduleDict(self):
        self.currentTime = currentTime.CurrentTime()
        event = self.event
        key = unicode(int(calendar.timegm((event.eventYear,
            event.eventMonth, event.eventDay, 6, 0, 0))))
        while key in self.scheduleDict:
            key += 60
        duration = event.totalTime
        value = [unicode(event.eventType),
            unicode(event.eventDescription), duration]

        self.scheduleDict[key] = value
        self.toSchedWrite = json.dumps(self.scheduleDict)
        with open("scheduledata.txt", "wt") as fout:
            fout.write(self.toSchedWrite)
            return "Scheduled"



    def readFile(filename, mode="rt"):
        # rt = "read text"
        with open(filename, mode) as fin:
            return fin.read()

    def writeFile(filename, contents, mode="wt"):
        # wt = "write text"
        with open(filename, mode) as fout:
            fout.write(contents)
