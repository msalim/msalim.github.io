#cal.py

#Dawn v0.0.3 Alpha
import time
import calendar

import currentTime

class CalConfig(object):
    def __init__(self):
        self.modifyCalendar()

    def modifyCalendar(self,shift=0):
        self.superTime = currentTime.CurrentTime()
        #self.superTime -= 1*shift*86400
        self.timeShift = (self.superTime.dayname*86400+
            self.superTime.hour*3600+self.superTime.minute*60+
            self.superTime.second+time.timezone)-(7*shift*86400)
        self.startDate = int(time.time() - self.timeShift)
        self.endDate = self.startDate + 7*86400
        
        self.absTimeShift = (self.superTime.dayname*86400+
            self.superTime.hour*3600+self.superTime.minute*60+
            self.superTime.second+time.timezone)
        self.absStartDate = int(time.time() - self.timeShift)
        self.absEndDate = self.startDate + 7*86400

        self.interval = 300
        self.rawTime = time.gmtime(self.startDate)
        self.month = self.rawTime.tm_mon
        self.year = self.rawTime.tm_year
        self.displayMonthname()
        self.calList = None
        self.startDay = time.gmtime(self.startDate)

    def displayMonthname(self):
        monthList = ["January", "February", "March", "April",
        "May", "June", "July", "August", "September", "October",
        "November", "December"]
        endDayList = [31,28,31,30,31,30,31,31,30,31,30,31]
        self.showMonth = monthList[self.month-1]
        self.monthCutOff = endDayList[self.month-1]


            
