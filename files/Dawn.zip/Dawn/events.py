import time
import currentTime
import calendar
import json

import re


#readFile / writeFile taken from 112 course notes

class Events(object):

    def __init__(self, text=""):
        self.superTime = currentTime.CurrentTime()
        self.originalText = text.lower()
        self.text = text.lower()
        self.eventType = None
        self.eventDescription = None
        self.currentHour = self.superTime.hour
        self.currentMinute = self.superTime.minute
        self.currentSecond = self.superTime.second
        self.currentTimezone = self.superTime.timezone
        self.currentDay = self.superTime.day
        self.currentMonth = self.superTime.month
        self.currentYear = self.superTime.year
        self.currentDayname = self.superTime.dayname
        self.currentFirstDayOfWeek = self.currentDay-self.currentDayname
        self.currentAMPM = self.superTime.AMPM
        if self.text == "": return None
        self.startPoint = 0
        self.endPoint = 999
        self.prepositionList = [" to"," for"," at"," from",
                                " until"," in", " by", " on"]
        self.setEventType()
       
    def setEventType(self):
        eventType = ["alarm", "reminder", "schedule", "delete", "event"]
        regex = [("set ?a?n? alarm ", "alarm ", "wake me up ",),
                    ("set ?a? reminder ", "remind me ", "reminde?r? ",),
                    ("schedule ",),
                    #("(search)( for)? ",),
                    ("delete ",),
                    #("meeting ", "meet "),
                    ("event ",)]
        self.eventTypeRegex = ""
        self.eventType = None
        for x in xrange(len(eventType)):
            for y in xrange(len(regex[x])):
                p = re.compile(regex[x][y])
                m = p.match(self.text)
                if m != None:
                    self.eventTypeRegex = regex[x][y]
                    self.eventType = eventType[x]
                    break
            if self.eventType != None:
                break
        self.startPoint = max(len(self.eventTypeRegex)-1, 0)
        if self.eventType == None: self.eventType = "event"
        if (self.eventType == "reminder" or self.eventType == "event" or
            self.eventType == "meeting" or self.eventType == "alarm"):
            self.setEventStartDate()
            self.setEventStartTime()
            self.setEventEndTime()
            self.setEventDescription()
        elif self.eventType == "delete":
            pass
        elif self.eventType == "schedule":
            self.setEventStartDate()
            self.setEventStartTime()
            self.setEventDuration()
            self.setEventDescription()
        return self.eventType

    def setEventStartDate(self):
        #by dayname
        regex = """(next )?(mon(day)?|tues?(day)?|wed(nesday)?|
        |thur?s?(day)?|fri(day)?|sat(urday)?|sun(day)?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            dateText = m.group()
            dayname = ["mon","tue","wed","thu","fri","sat","sun"]
            for x in xrange(len(dayname)):
                if dayname[x] in dateText:
                    dayOnWeek = x
                    day = self.currentFirstDayOfWeek+dayOnWeek
            if "next" in dateText:
                day += 7
            if self.currentDay > day:
                day += 7
            self.eventDay = day
            self.eventMonth = self.currentMonth
            self.eventYear = self.currentYear
            if self.endPoint > self.text.find(dateText):
                self.endPoint = self.text.find(dateText)
            return

        #by relative time
        regex = """(tomorrow|tmrw|(a|one|two|three|four|five|six|seven|
            |eight|nine|ten|eleven|twelve|[0-9]?[0-9]?[0-9]) days?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            dateText = m.group()
            self.eventDay = self.currentDay
            if "tomorrow" in dateText or "tmrw" in dateText:
                self.eventDay += 1
            if "day" in dateText and "days" not in dateText:
                self.eventDay += 1
            else:
                if dateText [:-5].isdigit() == False:
                    numbers = ["one", "two","three","four","five","six",
                        "seven","eight","nine","ten","eleven","twelve"]
                    for x in xrange(len(numbers)):
                        if numbers[x] in dateText:
                            self.eventDay += int(x+1)
                else:
                    self.eventDay += int(dateText[:-5])
            self.eventMonth = self.currentMonth
            self.eventYear = self.currentYear

            if self.endPoint > self.text.find(dateText):
                self.endPoint = self.text.find(dateText)

            return

        monthRegex = """(jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|
            |jun(e)?|jul(y)?|aug(ust)?|sep(tember)?|oct(ober)?|
            |nov(ember)?|dec(ember)?)"""
        regex = (""" [0-3]?[0-9]( |-|/)%s( |-|/)?((20)?[0-9][0-9])?"""
            % monthRegex)
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            dateText = m.group()
            dayRegex = "[0-3]?[0-9]( |-|/)"
            monthRegex = "( |-|/)%s" % monthRegex
            yearRegex = "(( |-|/)(20|\')[0-9][0-9])"

            p = re.compile(dayRegex)
            m = p.search(dateText)
            day = int(m.group()[:-1])

            p = re.compile(monthRegex)
            m = p.search(dateText)
            if m.group()[1:-1].isdigit(): month = int(m.group()[1:-1])
            else:
                monthName = ["jan","feb","mar","apr","may","jun",
                        "jul","aug","sep","oct","nov","dec"]
                for x in xrange(len(monthName)):
                    if monthName[x] in dateText:
                        month = x+1

            p = re.compile(yearRegex)
            m = p.search(dateText)
            if m == None: year = self.currentYear
            else: year = int(m.group()[1:])

            self.eventDay = day
            self.eventMonth = month
            self.eventYear = year

            if self.endPoint > self.text.find(dateText):
                self.endPoint = self.text.find(dateText)

            return

        else:       
            self.eventDay = self.currentDay
            self.eventMonth = self.currentMonth
            self.eventYear = self.currentYear
            return    

    def setEventStartTime(self):
        if self.eventType == "schedule":
            hour = 0
            minute = 0
        else:
            hour = self.currentHour
            minute = self.currentMinute

        skip = False
        regex = """((an|one|two|three|four|five|six|seven|eight|
        |nine|ten|eleven|twelve|[0-9]?[0-9]?[0-9]) ?h(our)?s?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            timeText = m.group()
            if (("hour" in timeText or "h" in timeText)
                and "hours" not in timeText):
                hour += 1
            else:
                if timeText [:-6].isdigit() == False:
                    numbers = ["one","two","three","four","five","six",
                    "seven","eight","nine","ten","eleven","twelve"]
                    for x in xrange(len(numbers)):
                        if numbers[x] in timeText:
                            hour += x+1
                else:
                    hour += int(timeText[:-6])

            #minute
        regex = """((twenty(.)*|thirty(.)*|fou?rty(.)*|
        |fifty(.)*) ?m(in)?(ute)?s?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            minuteText = m.group()
            tens = ["twenty","thirty","forty","fifty"]
            numbers = ["one","two","three","four","five","six",
            "seven","eight","nine"]
            for x in xrange(len(tens)):
                for y in xrange(len(numbers)):
                    if tens[x] in minuteText and numbers[y] in minuteText:
                        addMinutes = x*10+20 + y+1
                        minute += addMinutes
                        skip = True

        if skip == True: pass
        else:
            regex = """((one|two|three|four|five|six|seven|
            |eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|
            |sixteen|seventeen|eightt?een|nineteen|
            |[0-9]?[0-9]?[0-9]) ?m(in)?(ute)?s?)|(a min(ute)?)"""
            p = re.compile(regex)
            m = p.search(self.text)
            if m != None:
                minuteText = m.group()
                if (("minute" in minuteText) and "minutes" not in minuteText):
                    minute += 1
                else:
                    if minuteText[0].isdigit():
                        if minuteText[1].isdigit():
                            minute += int(minuteText[0:2])
                        else: minute += int(minuteText[0])
                    else:
                        numbers = ["one","two","three","four","five","six",
                        "seven","eight","nine","ten","eleven","twelve",
                        "thirteen","fourteen","fifteen","sixteen",
                        "seventeen","eightt?een","nineteen"]
                        for x in xrange(len(numbers)):
                            if numbers[x] in minuteText:
                                minute += x+1
                skip = True

        if hour != self.currentHour or minute != self.currentMinute:
            skip = True

        if skip == True: pass
        else: #hours
            regex = "[0-2]?[0-9](:[0-5][0-9])?( )?((a|am)|(p|pm))?"
            p = re.compile(regex)
            m = p.search(self.text)
            if m != None:
                timeText = m.group()
                hourRegex = "[0-2]?[0-9]"
                minuteRegex = ":[0-5][0-9]"
                AMPM = "((a|am)|(p|pm))"
                p = re.compile(hourRegex)
                m = p.search(timeText)
                hour = int(m.group())

                p = re.compile(minuteRegex)
                m = p.search(timeText)
                if m == None: minute = 0
                else: minute = int(m.group()[1:])

                p = re.compile(AMPM)
                m = p.search(timeText)
                try:
                    AMPM = m.group()
                    if AMPM == "pm": hour += 12
                except: pass
                
                skip = True
        
        hour -= self.currentTimezone
        while minute >= 60:
            minute -= 60
            hour += 1

        if self.eventType != "schedule":
            while (hour < self.currentHour-self.currentTimezone
                and self.eventDay <= self.currentDay):
                hour += 12

            try:
                if (AMPM[0].lower() == "p" and
                    (hour+self.currentTimezone-1)%24+1 < 12): hour += 12
                elif (AMPM[0].lower() == "a" and
                    (hour+self.currentTimezone-1)%24+1 >= 12): hour += 12
            except: pass
            
        while hour >= 24:
            hour -= 24
            self.eventDay += 1

        self.eventHour = hour
        self.eventMinute = minute
        self.eventSecond = self.currentSecond

        try:
            try:
                if self.endPoint > self.text.find(timeText):
                    self.endPoint = self.text.find(timeText)
            except:
                if self.endPoint > self.text.find(minuteText):
                    self.endPoint = self.text.find(minuteText)
        except: pass
        return

        #fix when AMPM not defined, add one day

    def setEventEndTime(self):
        self.eventEndDay = self.currentDay
        self.eventEndMonth = self.currentMonth
        self.eventEndYear = self.currentYear
        regex = """(to|till|until|up to|
            |-) [0-2]?[0-9](:[0-5][0-9])?( )?((a|am)|(p|pm))?"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            timeText = m.group()
            hourRegex = "[0-2]?[0-9]"
            minuteRegex = ":[0-5][0-9]"
            AMPM = "((a|am)|(p|pm))"
            p = re.compile(hourRegex)
            m = p.search(timeText)
            hour = int(m.group())

            p = re.compile(minuteRegex)
            m = p.search(timeText)
            if m == None: minute = 0
            else: minute = int(m.group()[1:])

            p = re.compile(AMPM)
            m = p.search(timeText)
            if m == None: AMPM = self.currentAMPM
            else: AMPM = m.group()
            if AMPM == "pm": hour += 12

            if hour < self.currentHour and self.eventEndDay < self.currentDay:
                hour += 12
                if hour >= 24:
                    hour -= 24
                    self.eventEndDay += 1

            hour -= self.currentTimezone
            while minute >= 60:
                minute -= 60
                hour += 1

            while (hour < self.currentHour-self.currentTimezone
                and self.eventEndDay <= self.currentDay):
                hour += 12
            
            try:
                if AMPM[0].lower() == "p" and (hour+self.currentTimezone-1)%24+1 < 12: hour += 12
                elif AMPM[0].lower() == "a" and (hour+self.currentTimezone-1)%24+1 >= 12: hour += 12
            except: pass
            
            while hour >= 24:
                hour -= 24
                self.eventEndDay += 1

            self.eventEndHour = hour
            self.eventEndMinute = minute
        
        else:
            self.eventEndHour = self.eventHour
            self.eventEndMinute = self.eventMinute

    def setEventDescription(self):
        if self.eventType == "alarm":
            self.eventDescription = "alarm"
            return
        desc = self.text[self.startPoint:self.endPoint]
        for x in xrange(len(self.prepositionList)):
            if self.prepositionList[x] in desc[:len(self.prepositionList[x])]:
                desc = desc[len(self.prepositionList[x])+1:]
            if (self.prepositionList[x] in desc[(len(desc)-len(self.prepositionList[x])-2):]):
                desc = desc[0:len(desc)-len(self.prepositionList[x])-1]
        try:
            while desc[0].isspace():
                desc = desc[1:]
        except: pass
        try:
            while desc[-1].isspace():
                desc = desc[:-1]
        except: pass
        self.eventDescription = desc

    def setEventDuration(self):
        skip = False
        hour = 0
        minute = 0
        regex = """((an|one|two|three|four|five|six|seven|eight|
        |nine|ten|eleven|twelve|twenty|[0-9]?[0-9]?[0-9]) ?h(our)?s?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            timeText = m.group()
            if (("hour" in timeText or "h" in timeText)
                and "hours" not in timeText):
                hour += 1
            else:
                if timeText [:-6].isdigit() == False:
                    numbers = ["one","two","three","four","five","six",
                    "seven","eight","nine","ten","eleven","twelve","13","14","15","16","17","18","19","twenty"]
                    for x in xrange(len(numbers)):
                        if numbers[x] in timeText:
                            hour += x+1
                else:
                    hour += int(timeText[:-6])

            #minute
        regex = """((twenty(.)*|thirty(.)*|fou?rty(.)*|
        |fifty(.)*) ?m(in)?(ute)?s?)"""
        p = re.compile(regex)
        m = p.search(self.text)
        if m != None:
            minuteText = m.group()
            tens = ["twenty","thirty","forty","fifty"]
            numbers = ["one","two","three","four","five","six",
            "seven","eight","nine"]
            for x in xrange(len(tens)):
                for y in xrange(len(numbers)):
                    if tens[x] in minuteText and numbers[y] in minuteText:
                        addMinutes = x*10+20 + y+1
                        minute += addMinutes
                        skip = True

        if skip == True: pass
        else:
            regex = """((one|two|three|four|five|six|seven|
            |eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|
            |sixteen|seventeen|eightt?een|nineteen|
            |[0-9]?[0-9]?[0-9]) ?m(in)?(ute)?s?)|(a min(ute)?)"""
            p = re.compile(regex)
            m = p.search(self.text)
            if m != None:
                minuteText = m.group()
                if (("minute" in minuteText) and "minutes" not in minuteText):
                    minute += 1
                else:
                    if minuteText[0].isdigit():
                        if minuteText[1].isdigit():
                            minute += int(minuteText[0:2])
                        else: minute += int(minuteText[0])
                    else:
                        numbers = ["one","two","three","four","five","six",
                        "seven","eight","nine","ten","eleven","twelve",
                        "thirteen","fourteen","fifteen","sixteen",
                        "seventeen","eightt?een","nineteen"]
                        for x in xrange(len(numbers)):
                            if numbers[x] in minuteText:
                                minute += x+1
        
        while hour > 0:
            minute += 60
            hour -= 1

        self.totalTime = minute 

    



