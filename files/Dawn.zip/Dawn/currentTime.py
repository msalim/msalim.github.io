#0.1.0a: conversions deprecated for localtime preference. :(

import time

class CurrentTime(object):
    def __init__(self):
        self.rawTime = time.localtime()
        self.year = self.rawTime.tm_year
        self.month = self.rawTime.tm_mon
        self.day = self.rawTime.tm_mday
        self.hour = self.rawTime.tm_hour
        self.minute = self.rawTime.tm_min
        self.second = self.rawTime.tm_sec
        self.dayname = self.rawTime.tm_wday
        self.daynumber = self.rawTime.tm_yday
        self.timezone = -1*(time.timezone/3600)
        self.dst = self.rawTime.tm_isdst
        self.displayAMPM()
        self.displayMonthname()
        self.displayDayname()
        if self.hour == 0: self.showHour = 12
        else: self.showHour = self.hour

        self.gmttime = time.gmtime()
        self.gmtyear = self.gmttime.tm_year
        self.gmtmonth = self.gmttime.tm_mon
        self.gmtday = self.gmttime.tm_mday
        self.gmthour = self.gmttime.tm_hour
        self.gmtminute = self.gmttime.tm_min
        self.gmtsecond = self.gmttime.tm_sec
        self.gmtdayname = self.gmttime.tm_wday
        self.gmtdaynumber = self.gmttime.tm_yday


    #UTCconfig adjusts date and time based on the UTC offset

    #displayAMPM adjusts the 12-hour notation accordingly
    def displayAMPM(self):
        if self.hour%24 < 12:
            self.AMPM = "AM"
        else: self.AMPM = "PM" 

    #displayMonthname converts the month number to month name
    def displayMonthname(self):
        monthList = ["January", "February", "March", "April",
        "May", "June", "July", "August", "September", "October",
        "November", "December"]
        endDayList = [31,28,31,30,31,30,31,31,30,31,30,31]
        self.showMonth = monthList[self.month-1]
        self.monthCutOff = endDayList[self.month-1]
    #displayDayname converts the day number to day name
    def displayDayname(self):
        dayList = ["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"]
        self.showDayname = dayList[self.dayname]
        
