#nextEvent.py
#determines the next event to occur
import time

import eventController
import currentTime


class NextAlarm(object):
    def __init__(self):
        self.eventController = eventController.EventController()
        self.eventsDict = self.eventController.eventsDict
        self.minValue = 99999999999999999
        timeNow = time.time()
        for key in self.eventsDict:
            if int(key) > timeNow and int(key) < self.minValue:
                if self.eventsDict[key][0] == "alarm":
                    self.minValue = int(key)
                else: pass
        if self.minValue == 99999999999999999: return None

        retrieve = time.localtime(self.minValue)
        self.alarmYear = retrieve.tm_year
        self.alarmMonth = retrieve.tm_mon
        self.alarmDay = retrieve.tm_mday
        self.alarmHour = retrieve.tm_hour
        self.alarmShowHour = (self.alarmHour-1)%12+1
        self.alarmMin = retrieve.tm_min
        self.alarmSec = retrieve.tm_sec
        self.alarmWeekDay = retrieve.tm_wday
        self.alarmDST = retrieve.tm_sec
        self.alarmTime = self.minValue
        self.displayAMPM()
        self.displayMonthname()
        self.displayDayname()

    def displayAMPM(self):
        if self.alarmHour%24 < 12:
            self.AMPM = "AM"
        else: self.AMPM = "PM" 

    def displayMonthname(self):
        monthList = ["January", "February", "March", "April",
        "May", "June", "July", "August", "September", "October",
        "November", "December"]
        endDayList = [31,28,31,30,31,30,31,31,30,31,30,31]
        self.eventMonthName = monthList[self.alarmMonth-1]

    def displayDayname(self):
        dayList = ["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"]
        self.eventDayName = dayList[self.alarmWeekDay]
        