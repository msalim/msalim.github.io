#nextEvent.py
#determines the next event to occur
import time

import eventController
import currentTime


class NextEvent(object):
    def __init__(self):
        self.eventController = eventController.EventController()
        self.eventsDict = self.eventController.eventsDict
        self.minValue = 99999999999999999
        timeNow = time.time()
        for key in self.eventsDict:
            if int(key) > timeNow and int(key) < self.minValue:
                if self.eventsDict[key][0] == "alarm": pass 
                else: self.minValue = int(key)
        if self.minValue == 99999999999999999: return None

        self.eventType = self.eventsDict[str(self.minValue)][0]
        self.eventName = self.eventsDict[str(self.minValue)][1]
        retrieve = time.localtime(self.minValue)
        self.eventYear = retrieve.tm_year
        self.eventMonth = retrieve.tm_mon
        self.eventDay = retrieve.tm_mday
        self.eventHour = retrieve.tm_hour
        self.eventShowHour = (self.eventHour-1)%12+1
        self.eventMin = retrieve.tm_min
        self.eventSec = retrieve.tm_sec
        self.eventWeekDay = retrieve.tm_wday
        self.eventDST = retrieve.tm_sec
        self.displayAMPM()
        self.displayMonthname()
        self.displayDayname()

    def displayAMPM(self):
        if self.eventHour%24 < 12:
            self.AMPM = "AM"
        else: self.AMPM = "PM" 

    def displayMonthname(self):
        monthList = ["January", "February", "March", "April",
        "May", "June", "July", "August", "September", "October",
        "November", "December"]
        endDayList = [31,28,31,30,31,30,31,31,30,31,30,31]
        self.eventMonthName = monthList[self.eventMonth-1]

    def displayDayname(self):
        dayList = ["Monday", "Tuesday", "Wednesday", "Thursday",
        "Friday", "Saturday", "Sunday"]
        self.eventDayName = dayList[self.eventWeekDay]
        